package com.capgemini.appl.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "Programs_Offered")
@Table(name = "Programs_Offered")
@NamedQueries({ @NamedQuery(name = "qryAllProgramOffered", query = "select p from Programs_Offered p"),
	@NamedQuery(name = "qryAllProgramsOffered", query = "select e from Programs_Offered e")	
})//////////Changed by Pooja

public class ProgramsOffered {

	private String programName;
	private String description;
	private String applicantEligility;
	private int duration;
	private String degreeCertificateOffered;
	private List<ProgramsScheduled> programSheduled;

	@OneToMany(mappedBy = "program")
	public List<ProgramsScheduled> getProgramSheduled() {
		return programSheduled;
	}

	public void setProgramSheduled(List<ProgramsScheduled> programSheduled) {
		this.programSheduled = programSheduled;
	}

	@Id
	@Column(name = "ProgramName")
	@NotEmpty(message = "ProgramName is Mandatory")
	@Size(min = 1, max = 10, message = "ProgramName must be of size 1 to 10")
	@Pattern(regexp="^[A-Za-z\\s]+$",message="ONLY ALPHABETS ARE ALLOWED")
	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	@Column(name = "description")
	@NotEmpty(message = "description is Mandatory")
	@Size(min = 1, max = 20, message = "description must be of size 1 to 20")
	public String getDescription() {
		return description;
	}

	

	

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "applicant_eligibility")
	@NotEmpty(message = "applicant_eligibility is Mandatory")
	@Size(min = 1, max = 40, message = "applicant_eligibility must be of size 1 to 40")
	public String getApplicantEligility() {
		return applicantEligility;
	}

	public void setApplicantEligility(String applicantEligility) {
		this.applicantEligility = applicantEligility;
	}

	@Column(name = "duration")
	//@NotEmpty(message = "duration is Mandatory")
	@NotNull(message="duration cannot be empty")
	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Column(name = "degree_certificate_offered")
	@NotEmpty(message = "degree_certificate_offered is Mandatory")
	@Size(min = 1, max = 10, message = "degree_certificate_offered must be of size 1 to 10")
	public String getDegreeCertificateOffered() {
		return degreeCertificateOffered;
	}

	public void setDegreeCertificateOffered(String degreeCertificateOffered) {
		this.degreeCertificateOffered = degreeCertificateOffered;
	}

	@Override
	public String toString() {
		return "ProgramsOffered [programName=" + programName + ", description="
				+ description + ", applicantEligility=" + applicantEligility
				+ ", duration=" + duration + ", degreeCertificateOffered="
				+ degreeCertificateOffered + "]";
	}

	

	

	
}
